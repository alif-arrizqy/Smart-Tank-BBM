<!-- All JQuery -->
<script src="<?= base_url('public/assets/node_modules/jquery/jquery-3.2.1.min.js') ?>"></script>

<!-- Tables -->
<script src="<?= base_url('public/assets/node_modules/popper/popper.min.js') ?>"></script>
<script src="<?= base_url('public/assets/node_modules/bootstrap/dist/js/bootstrap.min.js') ?>"></script>
<script src="<?= base_url('public/assets/dist/js/perfect-scrollbar.jquery.min.js') ?>"></script>
<script src="<?= base_url('public/assets/dist/js/waves.js') ?>"></script>
<script src="<?= base_url('public/assets/dist/js/sidebarmenu.js') ?>"></script>
<script src="<?= base_url('public/assets/dist/js/custom.min.js') ?>"></script>
<script src="<?= base_url('public/assets/node_modules/raphael/raphael-min.js') ?>"></script>
<script src="<?= base_url('public/assets/node_modules/morrisjs/morris.min.js') ?>"></script>
<script src="<?= base_url('public/assets/node_modules/jquery-sparkline/jquery.sparkline.min.js') ?>"></script>
<script src="<?= base_url('public/assets/dist/js/dashboard1.js') ?>"></script>

