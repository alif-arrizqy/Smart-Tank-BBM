<link rel="stylesheet" href="<?= base_url('public/assets/node_modules/morrisjs/morris.css') ?>">
<link rel="stylesheet" href="<?= base_url('public/assets/node_modules/fontawesome/css/all.min.css') ?>">   
<!-- Data Table -->
<link rel="stylesheet" href="<?= base_url('public/assets/dist/css/style.min.css') ?>">
<!-- Chart -->
<script src="<?= base_url('public/assets/dist/css/pages/dashboard1.css') ?>"></script>