<?php date_default_timezone_set("Asia/Jakarta");
$tahun = date("Y"); ?>
<footer class="footer">
    ©<?= $tahun ?> All Rights Reserved. <?=constant('FOOTER')?>
</footer>